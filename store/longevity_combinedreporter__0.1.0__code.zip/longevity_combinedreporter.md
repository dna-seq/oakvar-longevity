# Longevity reporter (pre alpha version) display your genome analysis related to longevity and disease risks

It consist now of 3 parts:
* Longevitymap report, show your longevity-related rsid and their influence.
* Cancer report, show cancer risks.
* Drug report, show how your genome influences drug effects.