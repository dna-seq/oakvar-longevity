# Longevity map (pre alpha version): list of rsids with other information that influence longevity based on Pedro database

Longevity map (pre alpha version) based on Pedro database. It contains research and publications related to longevity and ranges them by significance. It aggregate all research by rsid to feet annotator output format. Furthermore, it depends on dbsnp module and is the source of data for longevitymap reporter.

